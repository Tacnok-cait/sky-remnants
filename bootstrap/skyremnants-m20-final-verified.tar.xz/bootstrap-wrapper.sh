#!/bin/sh
set -eu
ROOT=$(CDPATH= cd -- "$(dirname -- "$0")" && pwd)
TARGET="$ROOT/gradle/wrapper/gradle-wrapper.jar"
URL="https://raw.githubusercontent.com/NeoForgeMDKs/MDK-1.21.1-ModDevGradle/main/gradle/wrapper/gradle-wrapper.jar"
mkdir -p "$(dirname "$TARGET")"
if command -v curl >/dev/null 2>&1; then
  curl -fL "$URL" -o "$TARGET"
elif command -v wget >/dev/null 2>&1; then
  wget -O "$TARGET" "$URL"
else
  echo "Install curl or wget, or copy the official wrapper JAR to $TARGET" >&2
  exit 1
fi
printf 'Downloaded official Gradle wrapper to %s\n' "$TARGET"
