# M9 Local Acceptance Result — 2026-07-30

M9 was accepted from the user-corrected and reverified full-project baseline.

- Unit tests: 28/28 passed.
- GameTests: 28/28 passed.
- `clean build`: passed.
- Dedicated-server smoke test: startup, normal stop and exit code all passed.
- The final development client remained running at the main menu.
- Client logs contained zero FATAL, ERROR or Exception entries.
- Missing textures: zero.
- New crash reports: zero.

Authoritative corrections included in the accepted baseline:

1. Mineral-cultivation modes use `bulkCost()`; the stale GameTest call to the removed `cobblestoneCost()` method was corrected.
2. The candidate package originally contained only 27 actual GameTests. External ecology initialization and player scan-record persistence, idempotence and isolation coverage were added, bringing the final total to 28.
3. Cattle and pig spawn candidates on the ecology island previously intersected leaves, causing the whole transactional group to roll back every second. The final implementation deterministically chooses four positions with empty feet and head space and solid ground, with a collision regression check.

Verified in game:

- A completely new `M9 External Islands Fresh` Sky Remnants world created successfully.
- The layer-rock resource island, ecology island, broken waystation and Wind-Eye trial island generated at the expected opening positions.
- Saving and reloading preserved the islands without duplicate generation.
- The complete cattle-and-pig group initialized successfully on the ecology island.
- After reload, the successful initialization record remained single, retry warnings remained zero and animals were not duplicated.
- The M8 airship save loaded with the existing airship still present.
- M7, M6, M5, M3/M4 and M2 acceptance saves loaded successfully.
- The default-world save loaded normally and retained vanilla terrain.

The uploaded `skyremnants-m9-corrected-full-project-20260730.zip` is the sole authoritative M10 baseline.
